const express = require('express');
const _ = require('lodash');

const app = express();

app.get('/nightly-report', (req, res) => {
  const summary = _.merge({}, { generated: new Date().toISOString() });
  res.json(summary);
});

app.listen(4000, () => console.log('reporting service listening on 4000'));
