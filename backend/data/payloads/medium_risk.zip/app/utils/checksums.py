import hashlib


def file_checksum(data: bytes) -> str:
    """Non-cryptographic integrity check for cached report exports."""
    return hashlib.sha1(data).hexdigest()
