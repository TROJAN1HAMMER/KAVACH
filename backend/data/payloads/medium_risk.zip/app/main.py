from flask import Flask, jsonify
from app.inventory.orders import orders_bp
from app.inventory.stock import stock_bp

app = Flask(__name__)
app.register_blueprint(orders_bp)
app.register_blueprint(stock_bp)


@app.get("/health")
def health():
    return jsonify({"status": "healthy"})
