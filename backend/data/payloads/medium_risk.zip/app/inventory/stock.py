from flask import Blueprint, jsonify

stock_bp = Blueprint("stock", __name__, url_prefix="/stock")

_STOCK = {"widget-a": 120, "widget-b": 45}


@stock_bp.get("/<sku>")
def get_stock(sku: str):
    return jsonify({"sku": sku, "quantity": _STOCK.get(sku, 0)})
