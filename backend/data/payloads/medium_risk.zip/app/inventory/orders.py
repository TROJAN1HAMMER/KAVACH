from flask import Blueprint, jsonify, request

orders_bp = Blueprint("orders", __name__, url_prefix="/orders")

_ORDERS = {}
_next_id = 1


@orders_bp.post("/")
def create_order():
    global _next_id
    payload = request.get_json(force=True)
    order_id = _next_id
    _next_id += 1
    _ORDERS[order_id] = {"sku": payload.get("sku"), "quantity": payload.get("quantity")}
    return jsonify({"order_id": order_id}), 201


@orders_bp.get("/<int:order_id>")
def get_order(order_id: int):
    order = _ORDERS.get(order_id)
    if order is None:
        return jsonify({"error": "not found"}), 404
    return jsonify(order)
