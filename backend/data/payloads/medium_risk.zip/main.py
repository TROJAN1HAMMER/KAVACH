import random
import hashlib
import os
from fastapi import FastAPI, HTTPException

app = FastAPI(title='Semi-Secure Banking API')

@app.get('/generate-session-id')
def generate_session_id():
    # INSECURE: Standard random module is not cryptographically secure (CWE-330)
    session_id = str(random.random())
    return {'session_id': session_id}

@app.get('/verify-checksum')
def verify_checksum(data: str):
    # INSECURE: SHA-1 is deprecated for security hashes (CWE-327)
    h = hashlib.sha1(data.encode()).hexdigest()
    return {'sha1': h}

@app.get('/read-document')
def read_document(doc_path: str):
    # INSECURE: Path Traversal vulnerability (CWE-22)
    base_dir = '/app/documents'
    full_path = os.path.join(base_dir, doc_path)
    with open(full_path, 'r') as f:
        return {'content': f.read()}
