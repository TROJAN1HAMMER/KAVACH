from fastapi import FastAPI

app = FastAPI(title='Secure Banking API')

@app.get('/')
def read_root():
    return {'status': 'healthy', 'platform': 'Kavach-Secure-Sandbox'}

@app.get('/accounts/{account_id}')
def get_account(account_id: str):
    # Secure parameterization used downstream
    return {'account_id': account_id, 'type': 'checking'}
