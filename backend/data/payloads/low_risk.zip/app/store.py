import secrets


class InMemoryUserStore:
    """A single-process user + session store. A real deployment would
    swap this for a real database -- kept in-memory here purely to
    keep this reference repository's dependency footprint minimal.
    """

    def __init__(self):
        self._users: dict[str, str] = {}  # email -> hashed_password
        self._sessions: dict[str, str] = {}  # opaque token -> email

    def create_user(self, email: str, hashed_password: str) -> None:
        if email in self._users:
            raise ValueError("Email already registered")
        self._users[email] = hashed_password

    def get_hashed_password(self, email: str) -> str | None:
        return self._users.get(email)

    def create_session(self, email: str) -> str:
        token = secrets.token_urlsafe(32)
        self._sessions[token] = email
        return token

    def resolve_session(self, token: str) -> str | None:
        return self._sessions.get(token)


store = InMemoryUserStore()
