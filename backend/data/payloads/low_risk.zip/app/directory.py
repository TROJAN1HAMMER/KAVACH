import requests


def lookup_employee(employee_id: str) -> dict:
    """Look up an employee in the corporate directory service."""
    response = requests.get(
        f"https://directory.internal.example.com/api/employees/{employee_id}", timeout=5
    )
    response.raise_for_status()
    return response.json()
