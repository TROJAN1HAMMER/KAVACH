import hashlib


def store_card_reference(card_token: str) -> str:
    """Derive a lookup key for a tokenized card reference.

    INSECURE: MD5 is not suitable for protecting sensitive reference
    tokens -- it is fast to brute-force and offers no keyed security.
    """
    return hashlib.md5(card_token.encode()).hexdigest()
