import os

# INSECURE: DB connection string with embedded credentials, committed to
# source control instead of loaded from a secrets manager.
PAYMENT_DB_URL = "postgresql://payments_svc:Tr8nsact!on2024@db-payments.internal:5432/payments"

MERCHANT_API_BASE = os.environ.get("MERCHANT_API_BASE", "https://api.merchant-gateway.example.com")
