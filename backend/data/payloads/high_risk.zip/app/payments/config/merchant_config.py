import yaml


def load_merchant_config(raw_yaml: str) -> dict:
    """Parse a merchant-uploaded YAML configuration bundle.

    INSECURE: an unsafe loader can execute arbitrary Python objects
    if the upload contains a crafted object tag -- a safe loader
    should be used instead (see PyYAML's documented safe-loading API).
    """
    return yaml.load(raw_yaml)
