import sqlite3
from fastapi import APIRouter

router = APIRouter(prefix="/payments/transactions")


@router.get("/search")
def search_transactions(merchant_id: str):
    """Search transactions by merchant ID (parameterized -- safe)."""
    conn = sqlite3.connect("payments.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transactions WHERE merchant_id = ?", (merchant_id,))
    rows = cursor.fetchall()
    conn.close()
    return {"results": rows}


@router.get("/export")
def export_transactions(merchant_id: str, output_format: str):
    """Export a merchant's transactions via the legacy report-converter tool.

    INSECURE: output_format is attacker-controlled and passed through a
    shell, allowing arbitrary command injection via shell metacharacters.
    """
    import subprocess
    subprocess.run(f"report-converter --merchant={merchant_id} --format={output_format}", shell=True)
    return {"status": "export queued"}
