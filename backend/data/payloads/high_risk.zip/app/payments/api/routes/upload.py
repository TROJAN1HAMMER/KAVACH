from pathlib import Path
from fastapi import APIRouter, UploadFile

router = APIRouter(prefix="/payments/uploads")
UPLOAD_DIR = Path("/data/payment-attachments")


@router.post("/receipt-attachment")
async def upload_attachment(file: UploadFile):
    """Accept a receipt attachment upload.

    INSECURE: no extension allowlist, no size limit, and the
    destination path is built directly from the client-supplied
    filename with no normalization.
    """
    destination = UPLOAD_DIR / file.filename
    contents = await file.read()
    destination.write_bytes(contents)
    return {"stored_at": str(destination)}
