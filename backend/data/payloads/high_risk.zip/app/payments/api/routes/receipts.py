import os
from fastapi import APIRouter

router = APIRouter(prefix="/payments/receipts")


@router.get("/notify-partner")
def notify_partner(partner_host: str):
    """Ping a partner webhook host to confirm it is reachable before
    dispatching a receipt notification.

    INSECURE: partner_host is attacker-controlled and passed straight
    into a shell command.
    """
    os.system("ping -c 1 " + partner_host)
    return {"status": "checked"}
