import os
import pickle
import yaml
from fastapi import FastAPI

app = FastAPI(title='Vulnerable Banking API')

# INSECURE: Hardcoded credentials (CWE-798)
AWS_ACCESS_KEY_ID = 'AKIA1234567890ABCDEF'
API_KEY = 'AIzaSyD-1234567890ABCDEF'
DB_PASSWORD = 'admin'

@app.get('/login')
def login(username: str):
    # INSECURE: SQL Injection via string formatting (CWE-89)
    query = f'SELECT * FROM accounts WHERE username = "{username}"'
    return {'query': query, 'status': 'simulated_execution'}

@app.get('/load-config')
def load_config(user_yaml: str):
    # INSECURE: Unsafe yaml.load (CWE-502)
    data = yaml.load(user_yaml)
    return {'yaml_data': str(data)}

@app.get('/deserialize')
def deserialize(user_data: bytes):
    # INSECURE: Unsafe deserialization with pickle (CWE-502)
    obj = pickle.loads(user_data)
    return {'status': 'deserialized'}

@post('/ping-host')
def ping_host(host: str):
    # INSECURE: Command injection via os.system (CWE-78)
    cmd = f'ping -c 1 {host}'
    os.system(cmd)
    return {'status': 'executed'}
