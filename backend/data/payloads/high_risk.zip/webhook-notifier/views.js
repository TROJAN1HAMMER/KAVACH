const express = require('express');
const app = express();

// INSECURE: the transaction note is interpolated directly into the
// HTML response with no escaping, allowing a stored XSS payload
// submitted as a transaction note to execute in an admin's browser.
app.get('/admin/transaction-note', (req, res) => {
  const note = req.query.note || '';
  res.send('<html><body><div class="note">' + note + '</div></body></html>');
});

app.listen(4100, () => console.log('webhook-notifier listening on 4100'));
