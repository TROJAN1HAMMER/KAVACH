import os
from flask import Blueprint, request, jsonify

admin_diagnostics_bp = Blueprint("admin_diagnostics", __name__)


@admin_diagnostics_bp.get("/admin/diagnostics/ping")
def ping_host():
    """INSECURE: the host parameter is attacker-controlled and passed
    straight into a shell command.
    """
    host = request.args.get("host", "")
    os.system("ping -c 1 " + host)
    return jsonify({"status": "executed"})
