from flask import Blueprint, send_from_directory

documents_bp = Blueprint("documents", __name__)


@documents_bp.get("/documents/<path:filename>")
def get_document(filename):
    return send_from_directory("/data/statements", filename)
