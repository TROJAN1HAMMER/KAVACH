import pickle
from flask import Blueprint, request, jsonify

session_bp = Blueprint("session", __name__)


@session_bp.get("/session/restore")
def restore_session():
    """INSECURE: deserializes a client-supplied cookie with pickle,
    which can execute arbitrary code for a crafted payload.
    """
    raw_cookie = request.cookies.get("session_data", "")
    session_obj = pickle.loads(bytes.fromhex(raw_cookie)) if raw_cookie else {}
    return jsonify({"restored": bool(session_obj)})
