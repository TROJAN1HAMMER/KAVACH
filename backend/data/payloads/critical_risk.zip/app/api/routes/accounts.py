import sqlite3
from flask import Blueprint, request, jsonify

accounts_bp = Blueprint("accounts", __name__)


@accounts_bp.get("/accounts/search")
def search_accounts():
    """INSECURE: the search term is concatenated directly into the SQL
    query instead of using a bound parameter.
    """
    name = request.args.get("name", "")
    conn = sqlite3.connect("core_banking.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM accounts WHERE holder_name LIKE '%" + name + "%'")
    rows = cursor.fetchall()
    conn.close()
    return jsonify({"results": rows})


@accounts_bp.get("/accounts/<account_id>")
def get_account(account_id):
    """INSECURE (structural, not pattern-detectable today): returns any
    account's data with no check that the caller owns it -- a real IDOR.
    Requires ast-grep/Joern cross-file authorization analysis.
    """
    conn = sqlite3.connect("core_banking.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM accounts WHERE account_id = ?", (account_id,))
    row = cursor.fetchone()
    conn.close()
    return jsonify({"account": row})
