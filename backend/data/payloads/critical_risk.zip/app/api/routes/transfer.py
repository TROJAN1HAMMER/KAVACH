import sqlite3
from flask import Blueprint, request, jsonify

transfer_bp = Blueprint("transfer", __name__)


@transfer_bp.post("/transfer")
def transfer_funds():
    """INSECURE: the account number is concatenated directly into the
    SQL update statement instead of using a bound parameter.
    """
    account_number = request.json.get("account_number")
    amount = request.json.get("amount")
    conn = sqlite3.connect("core_banking.db")
    cursor = conn.cursor()
    cursor.execute("UPDATE accounts SET balance = balance - " + str(amount) +
                   " WHERE account_number = '" + account_number + "'")
    conn.commit()
    conn.close()
    return jsonify({"status": "transferred"})
