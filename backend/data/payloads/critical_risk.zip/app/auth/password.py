import hashlib


def hash_password(plain_password: str) -> str:
    """INSECURE: MD5 has no place hashing account passwords -- it is
    unsalted here and trivially reversible via rainbow tables.
    """
    return hashlib.md5(plain_password.encode()).hexdigest()
