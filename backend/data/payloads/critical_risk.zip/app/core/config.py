# INSECURE: production credentials hardcoded directly in source.
DB_PASSWORD = "CoreBank_Prod_2019!"
AWS_ACCESS_KEY_ID = "AKIA27EXAMPLEKEYID11"
DEBUG = True
