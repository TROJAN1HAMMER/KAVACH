from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    assert client.get("/health").status_code == 200


def test_register_and_login():
    client.post("/register", json={"email": "demo@example.com", "password": "correct-horse-battery"})
    response = client.post("/login", json={"email": "demo@example.com", "password": "correct-horse-battery"})
    assert response.status_code == 200
    assert "access_token" in response.json()


def test_login_rejects_wrong_password():
    response = client.post("/login", json={"email": "demo@example.com", "password": "wrong-password"})
    assert response.status_code == 401
