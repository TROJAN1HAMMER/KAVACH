from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

from app.store import store
from app.schemas import UserCreate, UserLogin, UserOut, TokenOut
from app.security import hash_password, verify_password

app = FastAPI(title="KAVACH Demo -- Secure Authentication Service")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/login")


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(payload: UserCreate):
    try:
        store.create_user(payload.email, hash_password(payload.password))
    except ValueError:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already registered")
    return UserOut(email=payload.email)


@app.post("/login", response_model=TokenOut)
def login(payload: UserLogin):
    hashed = store.get_hashed_password(payload.email)
    if hashed is None or not verify_password(payload.password, hashed):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    return TokenOut(access_token=store.create_session(payload.email))


def get_current_user(token: str = Depends(oauth2_scheme)) -> str:
    email = store.resolve_session(token)
    if email is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")
    return email


@app.get("/me", response_model=UserOut)
def read_current_user(current_email: str = Depends(get_current_user)):
    return UserOut(email=current_email)
